# CS444_hw3

**All code runs and was tested on python 3.6.5**

# Part 1
Part 1 reads in 512 bits from urandom and conducts a run test. Also, it reads in the class coin flip data from class_bits.txt and it assumes the text file is in the same directory. For both data sets it prints out 0 if it is a good source of random and 1 if it not.

# Part 2
Code for challenges 6,7, and 8 are included. They all assume that their corresponding text file (6.txt, 7.txt and 8.txt) are located in the same directory to run. Each challenge will print out their answer to the console.